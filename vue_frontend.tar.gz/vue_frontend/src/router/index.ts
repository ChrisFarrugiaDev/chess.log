import DashboardView from '@/view/DashboardView.vue'
import GameView from '@/view/GameView.vue'
import { createRouter, createWebHistory } from 'vue-router'

const router = createRouter({
	history: createWebHistory(import.meta.env.BASE_URL),
	routes: [
		{ 
			path: '/', 
			name: 'mapView', 
			component: DashboardView,
			children: [
				{path: 'collection/:collectionId/game/:gameId', name: 'gameView', component: GameView, props: true}
			]
		 },
	],
})

export default router
