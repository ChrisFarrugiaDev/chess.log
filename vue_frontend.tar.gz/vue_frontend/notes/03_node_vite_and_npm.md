### axios

https://www.npmjs.com/package/axios
    
    npm install axios

<!-- --------------------------------------------------------------- -->

https://www.npmjs.com/package/@vueuse/core
https://vueuse.org/guide/

    $ npm install @vueuse/core

<!-- --------------------------------------------------------------- -->